package com.cg.emis.exception;

public class EmployeeException extends Exception {

	
	public EmployeeException()
	{
		
	}
	

	public EmployeeException(String s)
	{
		super(s);
	}
	
}
