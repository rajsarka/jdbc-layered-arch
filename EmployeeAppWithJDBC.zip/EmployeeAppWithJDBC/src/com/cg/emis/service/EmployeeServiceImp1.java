package com.cg.emis.service;

import java.util.ArrayList;

import javax.print.DocFlavor.STRING;

import com.cg.emis.bean.Employee;
import com.cg.emis.dao.EmployeeDAO;
import com.cg.emis.dao.EmployeeDAOImp1;
import com.cg.emis.exception.EmployeeException;

public class EmployeeServiceImp1 implements EmployeeService {

	EmployeeDAO dao;
	
	public EmployeeServiceImp1()
	{
		dao = new EmployeeDAOImp1();
	}
	
	
	@Override
	public Employee AddEmployee(Employee emp) throws EmployeeException {
		emp=dao.AddEmployee(emp);
		
		return emp;
	}

	@Override
	public ArrayList<Employee> getEmployeeList() throws EmployeeException {
		return dao.getEmployeeList();
		
	}

	@Override
	public Employee updateInsurancescheme(int id) throws EmployeeException {
		Employee emp= dao.getEmployee(id);
		if(emp==null)
			throw new EmployeeException("Emp id not found");
		double sal=emp.getSalary();
		String des= emp.getDesignation();
		
		if(sal >5000 && sal<=20000 && des.equals("System Associate"))
			emp.setInsuranceScheme("Scheme c");

		else if(sal >= 20000 && sal<=40000 && des.equals("Programmer"))
			emp.setInsuranceScheme("Scheme B");
		else if(sal >= 40000 && des.equals("Manager"))
			emp.setInsuranceScheme("Scheme A");
		else if(sal <5000 && des.equals("Clerk"))
				emp.setInsuranceScheme("No scheme");
		else
	            emp.setInsuranceScheme("NA");
		
		dao.AddEmployee(emp);
		return emp;
	}

	@Override
	public Employee deleteEmployee(int empid) throws EmployeeException {
		
		return dao.deleteEmployee(empid);
	}

	

}
