import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

//import com.cg.dbconnection.DatabaseConnection;

public class CRUD {
	
	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("\n1.Insert data \n2.Update data \n3.Delete data \n4.Display");
		System.out.println("Enter option : ");
		int op = sc.nextInt();
		Connection con= DatabaseConnect.getConnection();
		switch(op)
		{
		
		case 1:
			String sql = "insert into author1 values(?,?,?,?,?)";		
	
			
			try {
				PreparedStatement ps= con.prepareStatement(sql);
				System.out.println("Enter Aurthorid ");
				int id= sc.nextInt();
				System.out.println("Enter FirstName ");
				String name= sc.next();
				System.out.println("Enter MiddleName ");
				String mname = sc.next();
				System.out.println("Enter LastName ");
				String lname= sc.next();
				System.out.println("Enter Phone No. ");
				String sh= sc.next();
				
				ps.setInt(1,id);
				ps.setString(2, name);
				ps.setString(3, mname);
				ps.setString(4, lname);
				ps.setString(5, sh);
				
				int count=ps.executeUpdate();
				System.out.println("rows inserted : "+ count);
			} catch (SQLException e) {
				//e.printStackTrace();
				if(e.getErrorCode()==900)
				System.out.println("Insert Query Syntax is wrong");
				else if (e.getErrorCode()==1)
					System.out.println("Employee Id is already existing.Please try new value ");
				}
			break;
			
		case 2:
			
			String sql1 = "update author1 set firstname=?,lastname=?,middlename=?,phoneno=? where authorid=?";
			//Connection con1= DatabaseConnect.getConnection();
			try {
				PreparedStatement ps= con.prepareStatement(sql1);
				System.out.println("Enter Aurthorid ");
				int id= sc.nextInt();
				System.out.println("Enter FirstName ");
				String name= sc.next();
				System.out.println("Enter MiddleName ");
				String mname = sc.next();
				System.out.println("Enter LastName ");
				String lname= sc.next();
				System.out.println("Enter Phone No. ");
				String sh= sc.next();
				ps.setInt(5,id);
				ps.setString(1, name);
				ps.setString(2, mname);
				ps.setString(3, lname);
				ps.setString(4, sh);
				
				int count= ps.executeUpdate();
				if(count==0)
					System.out.println("Employee Record not Found");
				else
				System.out.println("Rows updated : "+ count );
			} catch (SQLException e) {
				
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
			
		case 3:
			String sql3 = "delete from author1 where authorid=?";
			//Connection con3= DatabaseConnect.getConnection();
			try {
				PreparedStatement ps= con.prepareStatement(sql3);
				System.out.println("Enter Author ID : ");
				int id = sc.nextInt();
				ps.setInt(1, id);
				
				int count= ps.executeUpdate();
				System.out.println("rows Deleted :"+ count);
			}catch(SQLException e) {
				System.out.println("invalid!!!!!");
			}
			break;
			
		case 4:
			String sql4 = "select * from author1 where authorid=?";
			//Connection con4= DatabaseConnect.getConnection();
			try {
				PreparedStatement ps= con.prepareStatement(sql4);
				System.out.println("Enter Author ID : ");
				int id = sc.nextInt();
				ps.setInt(1, id);
				
				ResultSet rs = ps.executeQuery();
				while(rs.next()) {
					int id1 = rs.getInt(1);
					String name = rs.getString(2);
					String mname = rs.getString(3);
					String lname = rs.getString(4);
					String ph = rs.getString(5);
					
					System.out.println(id1+"|"+name+"|"+mname+"|"+lname+"|"+ph);
				}
			}catch(SQLException e) {
				System.out.println("invalid!!!!!");
			}
			break;
		}
		}
}
