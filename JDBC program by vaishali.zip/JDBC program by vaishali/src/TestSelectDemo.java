import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public  class TestSelectDemo {

	public static void main(String[] args) {
		try {
			//load oracle type4 driver in memory
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//establishing connection with database and keeping the connection obj in con variable
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab2etrg7","lab2eoracle");
			
			String selQry1="Select emp_name,emp_id,"+"emp_sal,emp_doj FROM Employee ";
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(selQry1);
			System.out.println("ID \t Name\t\t Sal \t\t DOJ");
			while(rs.next())
			{
				System.out.println(rs.getInt(2)+"\t"+rs.getString(1)+" \t "+rs.getFloat(3)+" \t "+rs.getDate(4));
				//or 
				// System.out.println(rs.getInt("emp_id"));
				
				
			}
			
			
			
			
			
			
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}

	}

}
