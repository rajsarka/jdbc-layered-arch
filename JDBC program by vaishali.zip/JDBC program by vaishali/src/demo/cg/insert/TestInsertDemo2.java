package demo.cg.insert;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Scanner;

public  class TestInsertDemo2 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		try {
			//load oracle type4 driver in memory
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//establishing connection with database and keeping the connection obj in con variable
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab2etrg7","lab2eoracle");
			con.setAutoCommit(false);
			System.out.println("Enter EmpId:");
			int eid=sc.nextInt();
			System.out.println("Enter EmpName:");
			String enm=sc.next();
			System.out.println("Enter salary:");
			Float sal=sc.nextFloat();
			System.out.println("Enter Day of join:");
			int dd=sc.nextInt();
			System.out.println("Enter Day of Month:");
			int mm=sc.nextInt();
			System.out.println("Enter Day of Year:");
			int yy=sc.nextInt();
		LocalDate doj=LocalDate.of(yy, mm, dd);//local date
		Date mysqldoj=convertLocalToSQLDate(doj);//converting local date into sql date
		String insertQ="INSERT INTO Employee"+"(emp_id,emp_name,emp_sal,emp_doj) VALUES("+"?,?,?,?)";
		
		PreparedStatement pst=con.prepareStatement(insertQ);
		
		pst.setInt(1,eid);
		pst.setString(2, enm);
		pst.setFloat(3, sal);
		pst.setDate(4, mysqldoj);//sql date is passing
		
		
		
		int dataInserted=pst.executeUpdate();
		con.commit();
		System.out.println("Data inserted in the table"+dataInserted);
		
		
		
		
		
		
		
		
		
		
		
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}

	}

	private static java.sql.Date convertLocalToSQLDate(LocalDate doj) {
		Date mySqlDOJ=Date.valueOf(doj); //Date is from java.sql date
		return mySqlDOJ;
		
	}

}
