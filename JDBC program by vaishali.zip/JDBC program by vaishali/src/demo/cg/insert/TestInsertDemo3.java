package demo.cg.insert;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Scanner;

public  class TestInsertDemo3 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		try {
			//load oracle type4 driver in memory
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//establishing connection with database and keeping the connection obj in con variable
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g","lab2etrg7","lab2eoracle");
			
			String qry1="SELECT * from Employee";
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(qry1);
			ResultSetMetaData rsmd=rs.getMetaData();
			
			int colCount =rsmd.getColumnCount();
			System.out.println("No ofColumn: "+colCount);
			
			for(int i=1;i<=colCount;i++)
			{
				System.out.println(i +" :Col Name: "+rsmd.getColumnLabel(i));
				System.out.println("col type:"+rsmd.getColumnTypeName(i));
			}
			
		
		
		
		
		
		
		
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}

	}

	

}
