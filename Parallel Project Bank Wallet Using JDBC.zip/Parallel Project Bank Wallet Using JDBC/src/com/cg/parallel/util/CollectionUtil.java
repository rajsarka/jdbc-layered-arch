package com.cg.parallel.util;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import java.util.Scanner;

import com.cg.parallel.bean.Customer;
import com.cg.parallel.exception.CustomerException;

public class CollectionUtil {
	Connection con;
	public CollectionUtil() {
		
	con=DatabaseConnection.getConnection();
	}

	Scanner sc=new Scanner(System.in);
	
	
	
	
	public Customer AddCustomer(Customer cus) throws CustomerException {
		String sql="insert into Customer values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setString(1,cus.getMobileno());
			ps.setString(2, cus.getName());
			ps.setString(3, cus.getAadhar());
			ps.setString(4, cus.getBankname());
			ps.setString(5, cus.getAccno());
			ps.setLong(6, cus.getAmount());
			ps.setString(7, cus.getPword());
			int count = ps.executeUpdate();
			System.out.println("Row inserted: "+count);
		} 
		
		catch (SQLException e) {
			throw new CustomerException(e.getMessage());
		}
	return cus;
	}
	
	
	
	public ArrayList<Customer> getCustomerList() throws CustomerException {

		String sql="select cus_mobile,cus_name,cus_aadhar ,cus_bankname,cus_accno,cus_amount from Customer ";
	
		ArrayList<Customer> list= new ArrayList<>();
		Connection con= DatabaseConnection.getConnection();
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ResultSet rs= ps.executeQuery();
		
			while(rs.next()) {
				String mob= rs.getString(1);
				String name= rs.getString(2);
				String aadh= rs.getString(3);
				String bname= rs.getString(4);
				String accno= rs.getString(5);
				Long amount=rs.getLong(6);
	
				
				Customer cus= new Customer();
				cus.setMobileno(mob);
				cus.setName(name);
				cus.setAadhar(aadh);
				cus.setBankname(bname);
				cus.setAccno(accno);
				cus.setAmount(amount);
			
				list.add(cus);
			}
			
		}catch(SQLException e) {
			throw new CustomerException(e.getMessage());
		}
		
		return list;
	}
	
	public Customer showBalance(String mobileno) throws CustomerException{
		
		Customer cus=new Customer();
	String sql = "select cus_amount,cus_name,cus_accno,cus_bankname from Customer where cus_mobile=?";
	
	try {
		PreparedStatement ps= con.prepareStatement(sql);
		
		ps.setString(1,mobileno );
		
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			cus.setAmount(rs.getLong(1)); 
			cus.setName(rs.getString(2));
			cus.setAccno(rs.getString(3));
			cus.setBankname(rs.getString(4));
		}
	}
	catch(SQLException e) {
		throw new CustomerException(e.getMessage());
	}
	return cus;
	}
	


	public Customer addMoney(String mobno,long amt) throws CustomerException{
		String tranType="Credited";
		Customer cus=new Customer();
		cus=showBalance(mobno);
		long totalBalance=cus.getAmount()+amt;
		String update="update customer set cus_amount="+totalBalance+"where cus_mobile=?";
		try {
			PreparedStatement ps = con.prepareStatement(update);
			ps.setString(1,mobno );
			
			int count = ps.executeUpdate();
			System.out.println("Balance is Updated: "+count);
			cus.setAmount(totalBalance);;
			
			insertTransactions(mobno, amt, tranType);
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return cus;
	}
	
	
	public void insertTransactions(String mobno, long amt, String tranType) {
		String query="insert into Transaction(tran_id,mob_no,amount,tran_type,tran_date) values(?,?,?,?,?)";
		try {
			LocalDate localDate=LocalDate.now();
			Date sQLDate=convertLocalToSQLDate(localDate);
			Customer cust=new Customer();
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1,cust.getranNo());
			ps.setString(2, mobno);
			ps.setLong(3, amt);
			ps.setString(4, tranType);
			ps.setDate(5, sQLDate);
			int count = ps.executeUpdate();
			System.out.println("Transaction Row is inserted: "+count);
			
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	private java.sql.Date convertLocalToSQLDate(LocalDate localDate){
		Date sQLDate=Date.valueOf(localDate);
		return sQLDate;
	}
	
	public Customer withdraw(String mobno,long amt,String pwd) throws CustomerException{
		
		Customer cus=new Customer();
		String sql = "select cus_pwd from Customer where cus_mobile=?";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setString(1,mobno );
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				cus.setPword(rs.getString(1)); 
			}
		if(cus.getPword().equals(pwd))
			{
				String tranType="debited";
				
				cus=showBalance(mobno);
		if(cus.getAmount()>amt) {
				long totalBalance=cus.getAmount()-amt;
				String update="update customer set cus_amount="+totalBalance+"where cus_mobile=?";
			try {
					PreparedStatement ps1 = con.prepareStatement(update);
					ps1.setString(1,mobno );
					
					int count = ps.executeUpdate();
					System.out.println("Balance is Updated: "+count);
					cus.setAmount(totalBalance);;
					
					insertTransactions(mobno, amt, tranType);
					
					System.out.println("Your Balance "+ amt +" is debited with registered Mobile no "+mobno);
		
					}
			catch (SQLException e) {
							e.printStackTrace();
					}
				}
		else {
					System.out.println(" Your wallet doesn't have sufficient balance");

			}
			}
		else
		{
			System.out.println("Enter Correct Registered Password");
		}
		
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return cus;
	}
	
	
	public Customer fundTransfer(String mob1,String mob2,long amt,String pwd) throws CustomerException {
		Customer cus=new Customer();
		String sql = "select cus_pwd from Customer where cus_mobile=?";
		
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setString(1,mob1 );
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				cus.setPword(rs.getString(1)); 
			                 }
if(cus.getPword().equals(pwd))
{
			
			cus=showBalance(mob1);
	if(cus.getAmount()>amt) {
		Customer cust=new Customer();
		addMoney(mob2,amt);
		withdraw(mob1, amt,pwd);	
		System.out.println("Debited Rs. "+amt+" from "+mob1+" and credited Rs. "+amt+" to "+mob2);
			}
	else {
				System.out.println(" Your wallet doesn't have sufficient balance");

		}
}
else
{
		System.out.println("Enter Correct Registered Password");
}
		}
		
catch (SQLException e) 
		{
			e.printStackTrace();
		}
	return null;
	}


	public ArrayList<Customer> printTransaction(String mobno,String pwd) throws CustomerException {
		Customer cus=new Customer();
		ArrayList<Customer> list = null;
		String sql = "select cus_pwd from Customer where cus_mobile=?";
		
		try {
		PreparedStatement ps= con.prepareStatement(sql);
					
		ps.setString(1,mobno );
					
		ResultSet rs = ps.executeQuery();
		while(rs.next()) 
		{
			cus.setPword(rs.getString(1)); 
		}		
  if(cus.getPword().equals(pwd))
	{
				
		String query="select * from Transaction where mob_no=? and rownum<=5 order by tran_date desc";
		try {
			PreparedStatement ps1=con.prepareStatement(query);
			ps1.setString(1,mobno);
			ResultSet rs1=ps1.executeQuery();
			while(rs1.next()) {
				int tranId=rs1.getInt(1);
				String mobileNo=rs1.getString(2);
				String tranType=rs1.getString(3);
				Date date=rs1.getDate(4);
				long amount=rs1.getLong(5);
				
			
				String mob=String.valueOf(mobileNo).substring(6,10);
				String mob2="XXX-XXX-".concat(mob);
				if(tranType.equalsIgnoreCase("Debited"))
				{
					System.out.println(amount+" is "+tranType+" from "+mob2+" on "+date+" and Transaction Id is "+tranId);

				}
				
				else {
					System.out.println(amount+" is "+tranType+" to "+mob2+" on "+date+" and Transaction Id is "+tranId);

				}
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	else
	{
		System.out.println("Enter Correct Registered Password");
	}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		
	}

	

	
}