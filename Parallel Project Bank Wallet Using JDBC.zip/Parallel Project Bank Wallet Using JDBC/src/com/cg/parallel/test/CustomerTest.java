package com.cg.parallel.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;


import com.cg.parallel.dao.CustomerDAO;
import com.cg.parallel.dao.CustomerDAOImpl;
import com.cg.parallel.exception.CustomerException;
import com.cg.parallel.service.CustomerServiceValidator;

public class CustomerTest {

	CustomerServiceValidator validator=new CustomerServiceValidator();
	@Test
	public void testMethod1() {
		String name = "Rajib";
		boolean actual = validator.getValidateName(name);
		boolean expected =true;
		assertEquals(expected, actual);
	}
	@Test
	public void testMethod2() {
		String name = "rajib";
		boolean actual = validator.getValidateName(name);
		boolean expected =false;
		assertEquals(expected, actual);
	}
	
	
	@Test
	public void testMethod4() {
		String phone="8972479969";
		boolean actual = validator.getValidateMobNo(phone);
		boolean expected = true;
		assertEquals(expected, actual);
	}
	@Test
	public void testMethod5() {
		String phone="08972479969";
		boolean actual = validator.getValidateMobNo(phone);
		boolean expected = false;
		assertEquals(expected, actual);
	}
	@Test
	public void testMethod6() {
		String accNo="12365498";
		boolean actual = validator.getValidateAccNo(accNo);
		boolean expected = false;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testMethod7() {
		String accNo="123654";
		boolean actual = validator.getValidateAccNo(accNo);
		boolean expected = true;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testMethod8() {
		String bankName="bi";
		boolean actual = validator.getValidateBankName(bankName);
		boolean expected = false;
		assertEquals(expected, actual);
	}
	
	@Test
	public void testMethod9() {
		String pword="raj*123";
		boolean actual = validator.getValidatePassword(pword);
		boolean expected = true
				;
		assertEquals(expected, actual);
	}
	@Test
	public void testMethod10() {
		String pword="Kamd$123";
		boolean actual = validator.getValidatePassword(pword);
		boolean expected = false;
		assertEquals(expected, actual);
	}
	@Test(expected=NullPointerException.class)
	public void testMethod11() {
		
	CustomerDAO dao= new CustomerDAOImpl();
		try {
			dao.AddCustomer(null);
			
		} catch (CustomerException e) {
		
			e.printStackTrace();
		}
	}
}
