package com.cg.parallel.bean;

import java.time.LocalDate;

public class Transaction {
	public int transactionid;
	public String mobno;
	public Long amount;
	public String trantype;
	public LocalDate Date;
	public int getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(int transactionid) {
		this.transactionid = transactionid;
	}
	public String getMobno() {
		return mobno;
	}
	public void setMobno(String mobno) {
		this.mobno = mobno;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public String getTrantype() {
		return trantype;
	}
	public void setTrantype(String trantype) {
		this.trantype = trantype;
	}
	public LocalDate getDate() {
		return Date;
	}
	public void setDate(LocalDate date) {
		Date = date;
	}
	@Override
	public String toString() {
		return "Transaction [transactionid=" + transactionid + ", mobno=" + mobno + ", amount=" + amount + ", trantype="
				+ trantype + ", Date=" + Date + "]";
	}
	public Transaction(int transactionid, String mobno, Long amount, String trantype, LocalDate date) {
		super();
		this.transactionid = transactionid;
		this.mobno = mobno;
		this.amount = amount;
		this.trantype = trantype;
		Date = date;
	}
	public Transaction() {
		
	}
	
	
}
