package com.cg.contactbook.dao;

import com.cg.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public interface ContactBookDao {

	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;
	public EnquiryBean getEnquiryDetails(int EnqiryID) throws ContactBookException;
	
}
