package com.cg.contactbook.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.contactbook.exception.ContactBookException;

import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao {

	
	Map<Integer,EnquiryBean> customers=new HashMap<>();
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
customers.put(enqry.getEnquiryid(), enqry);
		return enqry.getEnquiryid();
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnqiryID) throws ContactBookException {
		EnquiryBean enq=customers.get(EnqiryID);
		return enq;
	}

}
