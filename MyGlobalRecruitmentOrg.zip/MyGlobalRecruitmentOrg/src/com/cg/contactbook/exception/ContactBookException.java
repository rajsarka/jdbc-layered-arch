package com.cg.contactbook.exception;

public class ContactBookException extends Exception{

	public ContactBookException() {
		super();
		
	}
	public ContactBookException(String s) {
		super(s);
		
	}
}

	

