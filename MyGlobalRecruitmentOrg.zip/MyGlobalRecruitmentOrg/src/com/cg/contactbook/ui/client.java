package com.cg.contactbook.ui;

import java.util.Random;
import java.util.Scanner;

import com.cg.contactbook.exception.ContactBookException;
import com.cg.contactbook.service.ContactBookService;
import com.cg.contactbook.service.ContactBookServiceImpl;

import com.igate.contactbook.bean.EnquiryBean;



public class client {

	public static void main(String[] args) {
		
		int option;
		Scanner sc=new Scanner(System.in);
		ContactBookServiceImpl service=new ContactBookServiceImpl();
		
		
		 
		 do {
			 EnquiryBean enqry= new EnquiryBean();
			
				
				
				System.out.println("1. Enter Enquiry details");
				System.out.println("2. View Enquiry Details on Id");
				System.out.println("0. Exit");
				
			 option = sc.nextInt();
			 switch(option) {
			 
			 case 1:
		try {
				 System.out.println("Enter first name");
				 String fname=sc.next();
				 System.out.println("Enter last name");
				 String lname=sc.next();
				 System.out.println("Enter contact number");
				 String mob=sc.next();
				 System.out.println("Enter Preferred Domain");
				 String dom=sc.next();
				 System.out.println("Enter Preferred Location");
				 String loc=sc.next();
				 
				 enqry.setContactNo(mob);
				 enqry.setIname(fname.concat(lname));
				 enqry.setpDomain(dom);
				 enqry.setpLocation(loc);

				 Random ran =new Random();
					int a = ran.nextInt(90000);
					enqry.setEnquiryid(a);
					
					int en=service.addEnquiry(enqry);
					System.out.println("Thank you"+enqry.getIname()+"your unique id is" + en+"/t we will contact you shortly");
                      
			 }
			 catch(ContactBookException e) 
				 {
				 System.out.println(e);
			     }
		break;
		
			 case 2:
				 try {
					 System.out.println("Enter Unique id");
					 int un=sc.nextInt();
					 enqry=service.getEnquiryDetails(un);
					 System.out.println(enqry.getContactNo()+"=>Phone no.");
					 System.out.println(enqry.getContactNo()+"=>Phone no.");
				 }
				 catch(ContactBookException e) 
				 {
				 System.out.println(e);
			     }
				 break;
				 
			 case 3:
				 System.exit(0);
				 }
		 }while(option!=4);
	}
	}
	

