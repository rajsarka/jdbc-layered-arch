package com.cg.contactbook.service;

import com.cg.contactbook.dao.ContactBookDao;
import com.cg.contactbook.dao.ContactBookDaoImpl;
import com.cg.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService {

	ContactBookDao dao;
	public ContactBookServiceImpl()
	{
		dao=new ContactBookDaoImpl();
	}
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		
		return dao.addEnquiry(enqry);
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnqiryID) throws ContactBookException {
		
		return dao.getEnquiryDetails(EnqiryID);
	}

}
