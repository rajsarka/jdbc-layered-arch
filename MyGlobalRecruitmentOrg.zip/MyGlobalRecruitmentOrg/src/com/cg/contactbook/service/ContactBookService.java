package com.cg.contactbook.service;

import com.cg.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public interface ContactBookService {

	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;
	public EnquiryBean getEnquiryDetails(int EnqiryID) throws ContactBookException;
	
}
