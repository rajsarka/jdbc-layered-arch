import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MobileException extends Exception {
public MobileException()
{
	
			
}
public MobileException(String message)
{
	super(message);
}

public static void mvalid(String str1)
{
Pattern p=Pattern.compile("^[7-9]{1}[0-9]{9}$");
Matcher m=p.matcher(str1);

try {
if(!m.find())
	throw new MobileException("invalid no");
else
	System.out.println("valid no");
}

catch(MobileException obj)
{
	System.out.println(obj);
	
}

}

}
