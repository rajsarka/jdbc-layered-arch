
public class Mypack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   System.out.println("hello");
   System.out.println();
	}

}
