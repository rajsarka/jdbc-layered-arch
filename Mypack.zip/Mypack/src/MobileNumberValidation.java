import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MobileNumberValidation {


	
	
	public static void main(String args[])
	{
		String str1="5981120269";
		MobileException obj=new MobileException();
		obj.mvalid(str1);
}
}