package com.cg.takehome.ui;

		import java.util.Scanner;

		import com.cg.takehome.bean.Product;
import com.cg.takehome.exception.ProductException;
import com.cg.takehome.service.ProductService;
import com.cg.takehome.service.ProductValidator;


public class Main {

	public static void main(String args[])
	{
		
		

			int option;
			Scanner sc=new Scanner(System.in);
			ProductService service =new ProductService();
			
			ProductValidator validator = new ProductValidator();
				
				Product prod =new Product();
				System.out.println("1. Enter Product id and quantity to generate Bill");
				System.out.println("2.Exit");
option =sc.nextInt();

switch(option) {
case 1:

	
	try {
System.out.println("Enter the product id");
int prodid=sc.nextInt();
if(validator.validateProdId(prodid)==false)

		throw new ProductException("Sorry ! The product id "+ prodid + " is not available");
	 

System.out.println("Enter Quantity");
int quant=sc.nextInt();
if (validator.validateqant(quant)== false)
	
		throw new ProductException("please enter valid quantity");
	 
prod=service.getProductDetails(prodid);

System.out.println("product id: " + prod.getProdid());
System.out.println("product name: " + prod.getProdname());
System.out.println("product price: " + prod.getPrice());
System.out.println("product category: " + prod.getProdcat());

double total= (quant*prod.getPrice());
System.out.println("line total: " + total);
	}
catch (ProductException e) {
	
	System.out.println(e.getMessage());;
}
	

break;
case 2:

	System.exit(0);
	break;
	
}
}
	}
