package com.cg.takehome.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProductValidator {
	public boolean validateProdId(int prodid)
	{		
	/*Pattern p=Pattern.compile("[1001,1002,1003,1004]{4}$");
	Matcher m=p.matcher(prodid);
		
		if (m.matches())*/ 
		if(prodid<1001 || prodid>1004){
			return false;
		}else
			return true;
	}
	
	public boolean validateqant(int quant) {
		
		if(quant>0)
		return true;
		else 
			return false;
		
		
	}
	
	
}
