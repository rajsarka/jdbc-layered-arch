package com.cg.takehome.service;

import com.cg.takehome.bean.Product;

public interface IProductService {

	public Product getProductDetails(int prodid);
	
	
}
