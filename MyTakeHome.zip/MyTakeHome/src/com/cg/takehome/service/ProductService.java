package com.cg.takehome.service;

import com.cg.takehome.bean.Product;
import com.cg.takehome.dao.ProductDAO;

public class ProductService implements IProductService {
	ProductDAO dao;
	public ProductService() {
		dao=new ProductDAO();
		
	}
public Product getProductDetails(int prodid) {
	return dao.getProductDetails(prodid);
	
	
}
}
