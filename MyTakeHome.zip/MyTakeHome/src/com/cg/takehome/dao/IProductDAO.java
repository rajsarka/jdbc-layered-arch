package com.cg.takehome.dao;

import com.cg.takehome.bean.Product;

public interface IProductDAO {

	public Product getProductDetails(int prodid);
}
