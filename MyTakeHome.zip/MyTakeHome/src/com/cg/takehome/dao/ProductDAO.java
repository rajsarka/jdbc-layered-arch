package com.cg.takehome.dao;

import com.cg.takehome.bean.Product;
import com.cg.takehome.service.IProductService;
import com.cg.takehome.util.CollectionUtil;

public class ProductDAO implements IProductDAO {
CollectionUtil ut;
	public ProductDAO(){
		ut=new CollectionUtil();
	}
	public Product getProductDetails(int prodid) {
		return ut.getProductDetails(prodid);
		
	}
}
