package com.cg.takehome.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.takehome.bean.Product;

public class CollectionUtil {

	private static Map<Integer,Product> products = new HashMap<Integer,Product>();
	static {
		products.put(1001, new Product("Iphone",1001,"Electronics",35000));
		products.put(1002, new Product("LEDTv",1002,"Electronics",45000));
		products.put(1003, new Product("Teddy",1003,"Toys",800));
		products.put(1004, new Product("Telescope",1004,"Toys",5000));
	
	
	
	}
	public Product getProductDetails(int prodid) {
	return products.get(prodid);
		
		
	}
}
