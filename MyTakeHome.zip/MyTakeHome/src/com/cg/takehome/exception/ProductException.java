package com.cg.takehome.exception;

public class ProductException extends Exception {

	public ProductException() {
}
	public ProductException(String s)
	{
		super(s);
		
	}
}

