package com.cg.takehome.bean;

public class Product {

	private int prodid;
	private String prodname;
	private String prodcat;
	private double price;
	private int quant;
	public Product(String prodname , int prodid, String prodcat, int price) {
		super();
		this.prodname = prodname;
		this.prodid = prodid;
		this.prodcat = prodcat;
		
		this.price = price;
	}
	
	public Product() {
		
	}

	public int getProdid() {
		return prodid;
	}
	public void setProdid(int prodid) {
		this.prodid = prodid;
	}
	public String getProdname() {
		return prodname;
	}
	public void setProdname(String prodname) {
		this.prodname = prodname;
	}
	public String getProdcat() {
		return prodcat;
	}
	public void setProdcat(String prodcat) {
		this.prodcat = prodcat;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuant() {
		return quant;
	}
	public void setQuant(int quant) {
		this.quant = quant;
	}
	@Override
	public String toString() {
		return "Product [prodid=" + prodid + ", prodname=" + prodname + ", prodcat=" + prodcat + ", price=" + price
				+ ", quant=" + quant + "]";
	}
	
	
	
}
