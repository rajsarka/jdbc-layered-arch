package com.cg.doctors.service;

import com.cg.doctors.bean.DoctorAppoiment;

public interface IDoctorAppointmentService {

	
	int addDoctorAppointmentDetails(DoctorAppoiment doctorAppointment );
	
	DoctorAppoiment getAppointmentDetails(int appointmentId) ;
}
