package com.cg.doctors.service;

import com.cg.doctors.bean.DoctorAppoiment;
import com.cg.doctors.dao.DoctorAppointmentDAO;


public class DoctorAppointmentService implements IDoctorAppointmentService {

	DoctorAppointmentDAO dao;
	public DoctorAppointmentService()
	{
		dao=new DoctorAppointmentDAO();
	}
	
	
	
	@Override
	public int addDoctorAppointmentDetails(DoctorAppoiment doctorAppointment) {
		
		return dao.addDoctorAppointmentDetails(doctorAppointment);
	}

	@Override
	public DoctorAppoiment getAppointmentDetails(int appointmentId) {
		
		return dao.getAppointmentDetails(appointmentId);
	}

}
