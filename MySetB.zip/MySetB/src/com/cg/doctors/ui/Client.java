package com.cg.doctors.ui;


import java.util.Scanner;
import java.util.Random;
import com.cg.doctors.bean.DoctorAppoiment;
import com.cg.doctors.exception.doctorException;
import com.cg.doctors.service.DoctorAppointmentService;







public class Client {

	public static void main(String[] args)  {
		
		
		int option;
		Scanner sc=new Scanner(System.in);
		DoctorAppointmentService service=new DoctorAppointmentService();
		
		 do {
			 DoctorAppoiment doc= new DoctorAppoiment();
				
				
				
				System.out.println("1. Book Doctor Appointment");
				System.out.println("2. View Doctor Appointment");
				System.out.println("3. Exit");
				
			 option = sc.nextInt();
		

		
			 switch(option) {
			 
			 case 1:
				 
				 try {
					System.out.println("Enter the name of the Patient");
					 String name=sc.next();
					 System.out.println("Enter email");
					 String mail=sc.next();
					 System.out.println("Enter  phone number");
					 String mob=sc.next();
					 System.out.println("Enter  Age");
					 int age=sc.nextInt();
					 System.out.println("Enter gender");
					 String gen=sc.next();
					 System.out.println("Enter Problem Name: Heart / Gynecology/Diabetes/ENT/Bone/Dermatology");
					 String prb=sc.next();
					 if(prb.equalsIgnoreCase("Heart"))
					 {
						 doc.setDoctorName("Dr brijesh Kumar");
						 doc.setAppointmentStatus("approved");
					 }
					 else if(prb.equalsIgnoreCase("Gynecology"))
					 {
						 doc.setDoctorName("Dr. Sharda Singh");
						 doc.setAppointmentStatus("approved");
					 }
					 else if(prb.equalsIgnoreCase("Diabetes"))
					 {
						 doc.setDoctorName("Dr.Henna Khan");
						 doc.setAppointmentStatus("approved");
					 }
					 else if(prb.equalsIgnoreCase("ENT"))
					 {
						 doc.setDoctorName("Dr.Paras Mai");
						 doc.setAppointmentStatus("approved");
					 }
					 else if(prb.equalsIgnoreCase("Bone"))
					 {
						 doc.setDoctorName("Dr. Renuka Kher");
						 doc.setAppointmentStatus("approved");
					 }
					 else if(prb.equalsIgnoreCase("Dermatology"))
					 {
						 doc.setDoctorName("Dr. Kanika Kapoor");
						 doc.setAppointmentStatus("approved");
					 }
					 else
					 {
						 doc.setAppointmentStatus("Disapproved");
					 }
						
					 Random ran =new Random();
						int a = ran.nextInt(90000);
						doc.setAppointmentId(a);
					 
					 doc.setPatientName(name);
					 doc.setEmail(mail);
					 doc.setPhoneNumber(mob);
					 doc.setAge(age);
					 doc.setGender(gen);
					 
					 
					 
					 

					 
						int apno= service.addDoctorAppointmentDetails(doc);
						 System.out.println("Your Doctor Appointment has been successfully registered,your appointment id is:"+apno);
				} catch (Exception e1) {
					
					e1.printStackTrace();
				}
					 break;
					 
			 case 2:
				 
				 try {
					System.out.println("Enter your Appointment id");
					 int apoid=sc.nextInt();
					
					
					 doc=service.getAppointmentDetails(apoid);
					 System.out.println("Patient Name: "+doc.getPatientName());
					 System.out.println("Appointment status: "+doc.getAppointmentStatus());
					 System.out.println("Doctor Name: "+doc.getDoctorName());
					 System.out.println("Appointment Date And time along with doctors's phone number will be shared shortly");
				} catch (NullPointerException e) {
					
					System.out.println("Appointment Id does not exist");
				}
				
				 
				 break;
				 
			 case 3:
				 System.exit(0);
			 }
			 
			 }while(option != 3);
		
		
	}
}
		
		
		
		

		 