package com.cg.doctors.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.doctors.bean.DoctorAppoiment;

public class DoctorAppointmentDAO implements IDoctorAppointmentDAO {

	           Map<Integer,DoctorAppoiment> appointments=new HashMap<>();
	
	public int addDoctorAppointmentDetails(DoctorAppoiment doctorAppointment) {
		
		appointments.put(doctorAppointment.getAppointmentId(), doctorAppointment);
		return doctorAppointment.getAppointmentId();
	}

	@Override
	public DoctorAppoiment getAppointmentDetails(int appointmentId) {
		DoctorAppoiment doc=appointments.get(appointmentId);
		return doc;
	}

	

}
