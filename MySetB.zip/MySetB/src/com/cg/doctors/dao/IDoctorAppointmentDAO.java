package com.cg.doctors.dao;

import com.cg.doctors.bean.DoctorAppoiment;

public interface IDoctorAppointmentDAO {

	int addDoctorAppointmentDetails(DoctorAppoiment doctorAppointment );
	
	DoctorAppoiment getAppointmentDetails(int appointmentId) ;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
