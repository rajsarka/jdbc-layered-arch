package com.cg.doctors.exception;

public class doctorException extends Exception{
	public doctorException() {
		super();
		
	}
	public doctorException(String s) {
		super(s);
		
	}
}
