package com.cg.dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertDemo {

	public static void main(String[] args) {
		//String query ="insert into Emp_insurance values(2,'Amit',1000,'clerk','B')";
		
		String query1 ="insert into emp_insurance values(?,?,?,?,?)";
		
		//String query1 ="insert into emp_insurance(name,empid,designation,salary)" + " values(?,?,?,?)";
		Scanner sc= new Scanner(System.in);
		Connection con =DatabaseConnection.getConnection();
	
		
		try {
			PreparedStatement ps= con.prepareStatement(query1);
			System.out.println("Enter empid");
			int id =sc.nextInt();
			System.out.println("Enter Name");
			String  name =sc.next();
			System.out.println("Enter Salary");
			Double  salary =sc.nextDouble();
			System.out.println("Enter designation");
			String ds =sc.next();
			System.out.println("Enter insurance scheme");
			String  sh =sc.next();
			
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setDouble(3, salary);
			ps.setString(4, ds);
			ps.setString(5, sh);
			
//			PreparedStatement ps= con.prepareStatement(query1);
//			System.out.println("Enter empid");
//			int id =sc.nextInt();
//			System.out.println("Enter Name");
//			String  name =sc.next();
//			System.out.println("Enter Salary");
//			Double  salary =sc.nextDouble();
//			System.out.println("Enter designation");
//			String ds =sc.next();
//			
//			ps.setInt(2, id);
//			ps.setString(1, name);
//			ps.setDouble(4, salary);
//			ps.setString(3, ds);
//			
			
			int count =ps .executeUpdate();
			
		System.out.println("row inserted : " + count);
		}
		catch(SQLException e)
		{
			//e.printStackTrace();
			if( e.getErrorCode()==90)
				System.out.println("enter correct query syntax");
				else if (e.getErrorCode()==1)
					System.out.println("primary key should not repeat..please enter unique emp id");
		}
	}

}
