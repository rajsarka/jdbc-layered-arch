package com.cg.dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class SelectDemo {

	public static void main(String[] args) {
		String sql= "select empid,name,salary,designation" + " from Emp_Insurance "+ " where insurance_scheme =?";
				Scanner sc= new Scanner(System.in);
		Connection con =DatabaseConnection.getConnection();
		try {
			System.out.println("Enter insurance scheme");
			String  scheme =sc.next();
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setString(1,scheme);
			ResultSet rs= ps.executeQuery();
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				double sal=rs.getDouble(3);
				String ds=rs.getString(4);
				
				System.out.println(id + " "+ name +"  "+ sal+ "  "+ ds+"  ");
			}
		}catch(SQLException e)
		{  
			e.printStackTrace();
			
		}

	
	}

}
