package com.cg.dbconnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdatableDemo {

	public static void main(String[] args) {
		Connection con =DatabaseConnection.getConnection();
		String sql ="select empid,name,salary,designation, insurance_scheme from Emp_Insurance"; 
		try {
			Statement s=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet rs=s.executeQuery(sql);
			while(rs.next())
			{
				int id=rs.getInt(1);
				if(id==5) {
					rs.updateString(5, "c");
					rs.updateRow();
					System.out.println("Record updated");
					
//					rs.deleteRow();
//					System.out.println("record deleted");
					
					
				}
				
			}

//			if(rs.next())
//			{	
//				rs.insertRow();
//				rs.updateInt(1, 10);
//				rs.updateString(2, "Esha");
//				
//			}
			
		}
		catch(SQLException e)
		{  
			e.printStackTrace();
			
		}
	}
}
