package com.cg.dbconnection;

public class F {

	public static void main(String[] args) {
		
		try {
			int x= args[0]/args[1];
			
		}

	}

}
