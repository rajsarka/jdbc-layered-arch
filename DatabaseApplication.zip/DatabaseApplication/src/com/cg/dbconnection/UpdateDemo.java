package com.cg.dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateDemo {

	public static void main(String[] args) {
		String query ="update emp_insurance set insurance_scheme=? where empid=? " ;
		
		//String query ="update emp_insurance set designation=? where empid=? " ;
		Scanner sc= new Scanner(System.in);
		Connection con =DatabaseConnection.getConnection();
		
		try {
			PreparedStatement ps= con.prepareStatement(query);
			System.out.println("Enter empid");
			int id =sc.nextInt();
			System.out.println("EnterInsurance scheme");
			String  sch =sc.next();
//			System.out.println("Enter designation");
//			String ds =sc.next();
			
			ps.setString(1, sch);
			ps.setInt(2, id);
		
//			ps.setString(1, ds);
//			ps.setInt(2, id);
//			
			int count=ps.executeUpdate();
			if(count==0)
				System.out.println("Employee record not fund");
			else
			System.out.println("Rows updated : " + count);
		
	}
		catch(SQLException e)
		{  
			e.printStackTrace();
			
		}

}
}
