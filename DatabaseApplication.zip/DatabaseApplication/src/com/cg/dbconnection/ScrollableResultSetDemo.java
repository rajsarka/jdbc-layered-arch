package com.cg.dbconnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ScrollableResultSetDemo {

	public static void main(String[] args) {
		Connection con =DatabaseConnection.getConnection();
		String sql ="select empid,name,salary,designation, insurance_scheme from Emp_Insurance"; 
		try {
			Statement s=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			ResultSet rs=s.executeQuery(sql);
			int row=1;
			System.out.println("Rownumber \tempid \tName \tsalary \tdesignation  \tscheme");
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				double sal=rs.getDouble(3);
				String ds=rs.getString(4);
				String scheme=rs.getString(5);
				System.out.println(id + " "+ name +"  "+ sal+ "  "+ ds+"  " + scheme+"  ");
				row++;
			}
			System.out.println("First row : " );
			if(rs.first())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				double sal=rs.getDouble(3);
				String ds=rs.getString(4);
				String scheme=rs.getString(4);
				System.out.println(id + " "+ name +"  "+ sal+ "  "+ ds+"  " + scheme+"  ");
			}
			
			System.out.println("display records in backward direction : " );
			if(rs.previous())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				double sal=rs.getDouble(3);
				String ds=rs.getString(4);
				String scheme=rs.getString(5);
				System.out.println(id + " "+ name +"  "+ sal+ "  "+ ds+"  " + scheme+"  ");
				
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}

	}

}
