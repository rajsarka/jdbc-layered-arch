package com.cg.dbconnection;


import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {

	public static Connection getConnection() {
	String driver =null;
		String url =null;
		String user =null;
		String pwd =null;
		
		Connection con=null;
		
		
		try {
		FileInputStream fis= new FileInputStream("./resources/dbconfig.properties");
		Properties pr= new Properties();
		pr.load(fis);
		driver=pr.getProperty("driver");
		user=pr.getProperty("username");
		pwd=pr.getProperty("password");
		url=pr.getProperty("url");
			
		Class.forName(driver);
		con=DriverManager.getConnection(url,user,pwd);
		System.out.println("connected to databse");
		}
		
		catch (SQLException e) {
			
			System.out.println(e.getMessage());
		} 
		
		catch (ClassNotFoundException e) {
			
			System.out.println(e.getMessage());
		} 
		
		catch (IOException e) {
			
			System.out.println(e.getMessage());
		}
		return con;
	}
	
	public static void main(String args[]) {
		
		getConnection();
	}
}
