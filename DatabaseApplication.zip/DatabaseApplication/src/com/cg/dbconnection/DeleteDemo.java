package com.cg.dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteDemo {

	public static void main(String[] args) {
		String query ="delete from Emp_insurance where empid=?";
		Scanner sc= new Scanner(System.in);
		Connection con =DatabaseConnection.getConnection();

		try {

			PreparedStatement ps= con.prepareStatement(query);
			System.out.println("Enter empid");
			int id =sc.nextInt();
			ps.setInt(1, id);
			int count =ps .executeUpdate();
			
			System.out.println("row deleted : " + count);
		}catch(SQLException e)
		{  
			e.printStackTrace();
			
		}

	}

}
