package com.cg.demo.bean;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;

public class TestSerialDemo {
	public static void main(String args[]) 
	{
		Employee e1=null;
		e1=new Employee(); //obj created with default constr
		
		Employee e2=new Employee(22,"Samir",6000.0F,LocalDate.now());
		System.out.println("AnnualSal=" +e2.getEmpSal()*12);
		
		
		
		
		
		try {
			FileOutputStream fos=new FileOutputStream("EmpInfo.txt");
			ObjectOutputStream oos=new 	ObjectOutputStream(fos);
//			oos.writeInt(e2.getEmpId());
//			oos.writeUTF(e2.getEmpName());
//			oos.writeFloat(e2.getEmpSal());
//			oos.writeObject(e2.getEmpDoj());
			
			oos.writeObject(e2);
			
			System.out.println("e2 instance data is"+"written in the file");
			
			
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
		
		
	}
}
