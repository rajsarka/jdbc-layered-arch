package com.cg.sale.dao;

import com.cg.sale.bean.Sale;
import com.cg.sale.exception.SaleException;

public interface ISaleDAO {

	public Sale getProduct(int id ) throws SaleException;
}
