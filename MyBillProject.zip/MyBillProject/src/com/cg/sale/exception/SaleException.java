package com.cg.sale.exception;

public class SaleException extends Exception{

	public SaleException(){
		
	}
	public SaleException(String s) {
		super(s);	
	}
	
}
