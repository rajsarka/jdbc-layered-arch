package com.cg.sale.service;

public interface IProductService {

}
