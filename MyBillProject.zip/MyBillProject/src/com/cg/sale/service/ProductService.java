package com.cg.sale.service;

public class ProductService implements IProductService
{

}
