package com.cg.parallel.pl;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.parallel.bean.Customer;
import com.cg.parallel.exception.CustomerException;
import com.cg.parallel.service.CustomerService;
import com.cg.parallel.service.CustomerServiceImpl;
import com.cg.parallel.service.CustomerServiceValidator;



public class Main {

	public static void main(String args[]) 
	{
		
		Scanner sc= new Scanner(System.in);	
		
		CustomerService service =new CustomerServiceImpl();
		CustomerServiceValidator validator=new CustomerServiceValidator();
		int option;
	
		do {
			
			Customer cus =new Customer();
			
			System.out.println("1. Create Wallet Account");
			System.out.println("2. Show Customer Details");
			System.out.println("3. Show balance");
			System.out.println("4. Deposite Money");
			System.out.println("5. Withdraw Money");
			System.out.println("6. Fund Transfer");
			System.out.println("7. Print Transactions");
			System.out.println("8. Exit --> ");
			
			System.out.println("Choose option...->");
		 option =sc.nextInt();
		
		
		switch(option){	
		case 1	:
			
			
			try {
	System.out.println("For Registration...\n Enter details...->");
	
	System.out.println("Enter your mobile no");
	String no =sc.next();
	if(validator.getValidateMobNo(no) == false)
		throw new CustomerException("Enter your Valid Phone number.");
	
	System.out.println("Enter your name");
	String name =sc.next();
	if(validator.getValidateName(name) == false)
		throw new CustomerException("Customer Name start should be  Capital.(Name length should be 3-20 alphabet)");
	
	System.out.println("Enter your aadhar no");
	String aadhar =sc.next();
	
	System.out.println("Enter your Bank your Name ");
	String bankname =sc.next();
	if(validator.getValidateBankName(bankname)==false)
		throw new CustomerException("Invalid bank Name.");
	
	System.out.println("Enter your Bank account no with which want to link");
	String acc =sc.next();
	if(validator.getValidateAccNo(acc)==false)
		throw new CustomerException("Enter Your Valid Account No.Account no must be 6 digit.");
	
	System.out.println("Enter password");
	String pword =sc.next();
	if(validator.getValidatePassword(pword)==false)
		throw new CustomerException("Enter Correct Password.");
	
	
	
	cus.setMobileno(no);
	cus.setName(name);
	cus.setAadhar(aadhar);
	cus.setBankname(bankname);
	cus.setAccno(acc);
	cus.setPword(pword);
	
	
	cus=service.AddCustomer(cus);
	System.out.println("Customer added " + cus.getMobileno());
	}
	
	catch(CustomerException e)
	{
		System.out.println(e.getMessage());
	}
	
	break;
			
		
		
		
		case 2:
			try {
				ArrayList<Customer> list= service.getCustomerList();
				for(Customer e : list)
				{
					System.out.println(e);
				}	
					
				}catch(CustomerException e) {
					System.out.println(e.getMessage());
				
				}
				break;
				
				
			
			case 3:
				
			try {
				System.out.println("Enter your Mobile no:");
				String mobno = sc.next();
				
				System.out.println("Enter your Password");
				String pwd = sc.next();
				if(validator.getValidatePassword(pwd)==false)
					throw new CustomerException("Enter Correct Password.");
				
//				ArrayList<Customer> list= service.getCustomerList();
//				for(Customer e : list) {
//				
//					
//						if(e.getPword().equals(pwd)) {
//							cus = service.showBalance(mobno);
//						System.out.println("Your balance is "+ cus.getAmount());
//						break;
//						}
//					
//					else 
//					
//
//					System.out.println("password incorrect");
//						break;
//				}
				
				cus=service.showBalance(mobno);
				System.out.println("Your balance is "+ cus.getAmount());
				
				}
			 
			catch (CustomerException e) {
				
				System.out.println(e.getMessage());
			}
				
				break;
				
			
			
			case 4:
				try {
					
				System.out.println("Enter your Mobile no:");
				String mobno = sc.next();
				
				System.out.println("Enter Amount Want To Deposite :");
				String amt = sc.next();
				
				cus = service.addMoney(mobno,Long.parseLong(amt));
			
				service.showBalance(cus.getMobileno());
				System.out.println("Your Balance "+ amt +" is credited.");
			} catch (CustomerException e) {
			System.out.println(e.getMessage());
			}
				
				
	break;
			case 5:
				try {
			System.out.println("Enter your mobile no");
			String mobno = sc.next();
			
			System.out.println("Enter your Password");
			String pwd = sc.next();
			if(validator.getValidatePassword(pwd)==false)
				throw new CustomerException("Enter Correct Password.");
			
			System.out.println("Enter Amount Want To withdraw :");
			String wamt = sc.next();
			
			cus = service.withdraw(mobno, Long.parseLong(wamt));
			
			service.showBalance(cus.getMobileno());
			System.out.println("Your Balance "+ wamt +" is debited");
		} catch (CustomerException e) {
		System.out.println(e.getMessage());
		}
			
		break;
		
			case 6:
				
				try {
					System.out.println("Enter Your Mobileno from which you want to Transfer fund:");
					String mobno1 = sc.next();
					
					System.out.println("Enter your Password");
					String pwd = sc.next();
					if(validator.getValidatePassword(pwd)==false)
						throw new CustomerException("Enter Correct Password.");
					
					System.out.println("Enter the Amount that you want to transfer .");
					String amt=sc.next();
					
					System.out.println("Enter Mobile no. to which you want to Transfer fund:");
					String mobno2 = sc.next();
										
					service.fundTransfer(mobno1,mobno2,Long.parseLong(amt));
		}catch(CustomerException e) {
			System.out.println(e);
		}
		break;		
			case 7:
				try {
				System.out.println("Enter your Mobile no.");
				String mobno= sc.next();
				
				System.out.println("Enter your Password");
				String pwd = sc.next();
				if(validator.getValidatePassword(pwd)==false)
					throw new CustomerException("Enter Correct Password.");
				
				ArrayList<Customer> list1 = service.printTransaction(mobno);
				for(Customer c:list1) {
					if(c.getMobileno().equals(mobno)) {
						System.out.println("Transaction Id= "+c.getranNo()+", Mobile No= "+c.getMobileno()+", Now Balance=  "+c.getAmount());
						break;
					}
					else 
						System.out.println("This "+mobno+" haven't created any transaction..");
						break;
					}
				} catch (CustomerException e) {
					System.out.println(e.getMessage());
				}
					
				
		break;	
				
				
			case 8:
				System.exit(0);
	}
		
	}while(option != 8);
	}
}


