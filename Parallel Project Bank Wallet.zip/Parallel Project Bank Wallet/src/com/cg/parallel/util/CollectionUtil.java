package com.cg.parallel.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.cg.parallel.bean.Customer;
import com.cg.parallel.exception.CustomerException;

public class CollectionUtil {
	 Map<String,Customer> customers= new HashMap<String,Customer>(); 
	 Map<String,Customer> hash = new HashMap<>();
	public CollectionUtil() {
		
		customers.put("8981120269", new Customer ("8981120269", "Rajib", "123456789123", "Axis", "16501613066", 20000, "raj@493" ));
		customers.put("7898820258", new Customer ("7898820258", "Raja", "258966789123", "SBI", "15101511088", 25000, "raj@456" ));
		customers.put("8910959439", new Customer ("8910959439", "Ranit", "654123789123", "SBI", "17501618066", 19000, "ran@789" ));
		customers.put("8441120255", new Customer ("8441120255", "Arjun", "123455589123", "HDFC", "18501513066", 25500, "arj@012" ));
	}
	
	public Customer AddCustomer(Customer cus) throws CustomerException {
		customers.put(cus.getMobileno(), cus);
			return cus;
		}
	public ArrayList<Customer> getCustomerList() throws CustomerException {
		Collection<Customer> c1= customers.values();
		ArrayList<Customer> list =new ArrayList<>(c1);
		return list;
	}
	public Customer showBalance(String mobileno) throws CustomerException {
		Customer cus=customers.get(mobileno);
		long balance = cus.getAmount();
		return cus;
	}

	public Customer addMoney(String mobno, Long amt) throws CustomerException {
	Customer cus = customers.get(mobno);
	Long currentbalance= cus.getAmount();
	Long Totalbalance=currentbalance + amt;
		cus.setAmount(Totalbalance);
		hash.put(mobno,cus);
		return cus;
	}
	
	
	public Customer withdraw(String mobno,long  wamt) throws CustomerException{
		Customer cus = customers.get(mobno);
		Long currentbalance= cus.getAmount();
		Long Totalbalance=currentbalance - wamt;
			cus.setAmount(Totalbalance);
			hash.put(mobno,cus);
			return cus;
		
		}
	
	public Customer fundTransfer(String mobno1,String mobno2,long famt) throws CustomerException {
		long curBalance1;
		long curBalance2;
		Customer cust1 = customers.get(mobno1);
		Customer cust2 = customers.get(mobno2);
		if(cust1==null)
			throw new NullPointerException("Your Mobile No. is not Exist.");
		else	
			 curBalance1 = cust1.getAmount();
		
		if(cust2==null)
			throw new NullPointerException("Your Mobile No. is not Exist.");
		else
			curBalance2 = cust2.getAmount();
		
		long totalBalance1 = curBalance1-famt;
		long totalBalance2 = curBalance2+famt;
		cust1.setAmount(totalBalance1);
		cust2.setAmount(totalBalance2);
		hash.put(mobno1, cust1);
		hash.put(mobno2, cust2);
		
		System.out.println("Debited Rs. "+famt+" from "+mobno1+" and credited Rs. "+famt+" to "+mobno2);
		return null;
	}
	
public ArrayList<Customer> printTransaction(String mobno) throws CustomerException {
		
		Collection<Customer> c = hash.values();
		ArrayList<Customer> list2 = new ArrayList<>(c);
		return list2;
		
	}

}