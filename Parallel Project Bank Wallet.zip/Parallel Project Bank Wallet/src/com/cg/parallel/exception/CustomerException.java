package com.cg.parallel.exception;


public class CustomerException extends Exception {


	public CustomerException()
	{
		
	}
	

	public CustomerException(String s)
	{
		super(s);
	}
	
	
}
