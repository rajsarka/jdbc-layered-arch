package com.cg.parallel.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;


import com.cg.parallel.bean.Customer;
import com.cg.parallel.exception.CustomerException;
import com.cg.parallel.util.CollectionUtil;


public class CustomerDAOImpl implements CustomerDAO{

	CollectionUtil ut;
	
	public CustomerDAOImpl() {
		ut=new CollectionUtil();
	}
	
	public Customer AddCustomer(Customer cus) throws CustomerException {
	return ut.AddCustomer(cus);
	}
	
	public ArrayList<Customer> getCustomerList() throws CustomerException {
		return ut.getCustomerList();
	}

	public Customer showBalance(String mobileno) throws CustomerException {
		return ut.showBalance(mobileno);
		
	}
	
	public Customer addMoney(String mobno,long amt) throws CustomerException {
		return ut.addMoney(mobno,amt);
		
	}

	@Override
	public Customer withdraw(String mobno, long wamt) throws CustomerException {
		
		return ut.withdraw(mobno, wamt);
	}

	public Customer fundTransfer(String mobno1,String mobno2,long famt) throws CustomerException{
		return ut.fundTransfer(mobno1, mobno2, famt);
		
		
	}

	public ArrayList<Customer> printTransaction(String mobno) throws CustomerException{
		return ut.printTransaction(mobno);
	}
	

	




	
	
		
	
}
