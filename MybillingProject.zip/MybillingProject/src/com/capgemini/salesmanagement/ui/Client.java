package com.capgemini.salesmanagement.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exception.SaleException;
import com.capgemini.salesmanagement.service.SaleValidation;
import com.capgemini.salesmanagement.service.Saleservice;


public class Client {

	public static void main(String[] args) throws SaleException {
		/*Client c= new Client();
		double p=Math.random();*/
		
		int option;
		Scanner sc=new Scanner(System.in);
		Saleservice service=new Saleservice();
		SaleValidation validator = new SaleValidation();
		do {
			
			Sale sale =new Sale();
			//double m=sale.setSaleid(Math.random());
			System.out.println("1. add product details");
			System.out.println("2. show product list with final bill");
			System.out.println("3. exit");
			
		 option = sc.nextInt();
		 
		 switch(option) {
		 case 1:
			 try {
			 System.out.println("Enter the product code");
		 int prodcode = sc.nextInt();
		 if(validator.validateProductCode(prodcode)==false)
			 throw new SaleException("Sorry ! The product code "+ prodcode + " is not available");
		 
		 System.out.println("Enter the quantity");
		 int quant = sc.nextInt();
		 if(validator.validateQuantity(quant)==false)
			 throw new SaleException("Enter valid quantity "+ quant );
		 
		 System.out.println("Enter the product category");
		 String prodcat = sc.next();
		 if(validator.validateProductCat(prodcat)==false)
			 throw new SaleException("Enter valid category "+ prodcat );
		
		 
		 System.out.println("Enter the product name");
		 String prodname = sc.next();
		 if(validator.validateProductName(prodname)==false)
			 throw new SaleException("Enter valid price"+ prodname);
		
		 System.out.println("Enter the product price");
		 double price = sc.nextDouble();
		 if(validator.validateProductPrice(price)==false)
		 throw new SaleException("Enter valid price"+ price);
		 
			sale.setProdcode(prodcode);
			sale.setQuantity(quant);
			sale.setProductname(prodname);
			sale.setCategory(prodcat);
			sale.setLinetotal(quant*price);
			
			Random ran =new Random();
			int a = ran.nextInt(90000);
			sale.setSaleid(a);
			
			sale.setSaleDate(LocalDate.now());
			
			sale=service.insertSalesDetails(sale);
			
			
			System.out.println("your product ready to sale and saleid is : " +sale.getSaleid() +" and selling date is " + sale.getSaleDate());
			 }
			 
			 catch(SaleException e)
			 {
				 System.out.println(e.getMessage());
			 }
			break;
			
		 case 2 :
			 try {
			System.out.println("enter product code");
			int prodid=sc.nextInt();
			if(validator.validateProductCode(prodid)==false)
				 throw new SaleException("Sorry ! The product code "+ prodid + " is not available");
			 
			ArrayList<Sale> list = service.getCollection(prodid);
			System.out.println(list);
			 }
			 catch(SaleException e1)
			 {
				 System.out.println(e1);
			 }
			
			/*sale=service.insertSalesDetails(sale);
			System.out.println(sale.getCategory());
			System.out.println(sale.getProdcode());
			System.out.println("your product ready to sale and saleid is : " +sale.getSaleid() +" and selling date is " + sale.getSaleDate());
			*/
		 break;
		 
	
		 
		 case 3:
			 System.exit(0);
			 break; 
			
		 }
			
			
		}while(option != 5);
		
		
		
		
		
		
		
		
		
	}

}
