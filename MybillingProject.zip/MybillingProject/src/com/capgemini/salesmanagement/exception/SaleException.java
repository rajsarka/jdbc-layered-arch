package com.capgemini.salesmanagement.exception;

public class SaleException extends Exception {

	public SaleException() {
		super();
		
	}
	public SaleException(String s) {
		super(s);
		
	}

}
