package com.capgemini.salesmanagement.service;

public class SaleValidation {

	public boolean validateProductCode(int producid) {
		if(producid<1001 || producid>1004){
			return false;
		}else
			return true;
	}
	

	public boolean validateProductCat(String prodcat) {
		if(prodcat == "Electronics" || prodcat =="Toys")
		{
			return false;
		}
		else
			return true;
	}
	

	public boolean validateProductName(String prodname) {
		
		 
				if(prodname == "TV" || prodname == "Soft Toy" || prodname == "Smart Phone" || prodname == "Video Game" || prodname == "Telescope" || prodname == "Barbee Doll"  ){
			return false;
		}else
			return true;
	}
	

	public boolean validateProductPrice(double price) {
		if(price<200 ){
			return false;
		}else
			return true;
	}

	 public boolean validateQuantity(int qty) {
			if(qty <0 || qty >5){
				return false;
			}else
				return true;
	}
	
}
