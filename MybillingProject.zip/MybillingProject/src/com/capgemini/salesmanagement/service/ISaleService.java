package com.capgemini.salesmanagement.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;

public interface ISaleService {
	public Sale insertSalesDetails(Sale sale);
	public ArrayList<Sale> getCollection(int prodid);
	
}
