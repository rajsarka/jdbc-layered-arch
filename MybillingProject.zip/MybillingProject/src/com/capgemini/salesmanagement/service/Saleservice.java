package com.capgemini.salesmanagement.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.dao.*;
public class Saleservice implements ISaleService {
SaleDAO dao;
	public Saleservice ()
	{
		dao=new SaleDAO();
	}
	@Override
	public Sale insertSalesDetails(Sale sale) {
		
		return dao.insertSalesDetails(sale);
	}

	public ArrayList<Sale> getCollection(int prodid) {
		
		return dao.getCollection(prodid);
	}

}
