package com.capgemini.salesmanagement.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;

public interface ISaleDAO {

	public Sale insertSalesDetails(Sale sale);
	public ArrayList<Sale> getCollection(int prodid);
}
