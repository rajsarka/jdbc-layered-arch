package com.capgemini.salesmanagement.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class SaleDAO implements ISaleDAO {

	CollectionUtil ut;
	public SaleDAO()
	{
		ut=new CollectionUtil();
	}
	
	public Sale insertSalesDetails(Sale sale) {
		return ut.insertSalesDetails(sale);
	}

	@Override
	public ArrayList<Sale> getCollection(int prodid) {
		
		return ut.getCollection(prodid);
	}
}
