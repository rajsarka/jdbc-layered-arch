package com.capgemini.salesmanagement.bean;

import java.time.LocalDate;

public class Sale {

	private double saleid;
	private int prodcode;
	private String productname;
	private String category;
	private int quantity;
	private double linetotal;
	private LocalDate saleDate;
	
	public double getSaleid() {
		return saleid;
	}
	public double setSaleid(double saleid) {
		return this.saleid = saleid;
	}
	public int getProdcode() {
		return prodcode;
	}
	public void setProdcode(int prodcode) {
		this.prodcode = prodcode;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getLinetotal() {
		return linetotal;
	}
	public void setLinetotal(double d) {
		this.linetotal = d;
	}
	@Override
	public String toString() {
		return "saleid=" + saleid + ", prodcode=" + prodcode + ", productname=" + productname + ", category="
				+ category + ", quantity=" + quantity + ", linetotal=" + linetotal + ", saleDate=" + saleDate + "]";
	}
	public LocalDate getSaleDate() {
		return saleDate;
	}
	public void setSaleDate(LocalDate saleDate) {
		this.saleDate = saleDate;
	}
	public Sale(int saleid, int prodcode, String productname, String category, int quantity, float linetotal,
			LocalDate saleDate) {
		super();
		this.saleid = saleid;
		this.prodcode = prodcode;
		this.productname = productname;
		this.category = category;
		this.quantity = quantity;
		this.linetotal = linetotal;
		this.saleDate = saleDate;
	}
	public Sale() {
		//super();
		
	}
	
	
	
	
}
