package com.capgemini.salesmanagement.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exception.SaleException;

public class CollectionUtil  {

	private static Map<Integer,Sale> sales = new HashMap<Integer,Sale>();
	
	public Sale insertSalesDetails(Sale sale) {
		 sales.put((int) sale.getSaleid(), sale);
		return sale;
		}
	
	public  ArrayList<Sale> getCollection(int prodid){
		Collection<Sale> c1=sales.values();
		ArrayList<Sale> list = new ArrayList<>(c1);
		return list;
		
	}
	}
